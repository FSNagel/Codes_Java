class Ingresso{
	private double valor = 50.00;

	public double getValor(){
		return this.valor;
	}

	public void setValor(double $dado){
		this.valor = $dado;
	}

}