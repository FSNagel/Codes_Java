import javax.swing.*;
import java.awt.GridLayout;
import java.awt.event.*; 



class Post implements ActionListener{
	private String title;
	private String date;
	private String content;
	private int likes;
	private int dislikes;

	public JPanel panel;
	public JTextField titleJ;
	public JTextField dateJ;
	public JTextArea contentJ;


	public String getTitle(){
		return this.title;
	}

	public void setTitle(String value){
		this.title = value;
	}

	public String getDate(){
		return this.date;
	}

	public void setDate(String value){
		this.date = value;
	}

	public String getContent(){
		return this.content;
	}

	public void setContent(String value){
		this.content = value;
	}

	public int getLikes(){
		return this.likes;
	}

	public void setLikes(int value){
		this.likes = value;
	}

	public int getDislikes(){
		return this.dislikes;
	}

	public void setDislikes(int value){
		this.dislikes = value;
	}

	public void Show(){
		System.out.println("Show da Post");
	}

	public void like(){
		this.likes += 1;
		System.out.println("Total de likes: " + this.likes);
	}

	public void dislike(){
		this.dislikes += 1;
		System.out.println("Total de likes: " + this.dislikes);
	}

	public JPanel getPanel(){
		this.panel 	  = new JPanel();

		this.titleJ   = new JTextField("Digite o titulo", 46);
		this.dateJ    = new JTextField("Informe a data", 46);
		this.contentJ = new JTextArea("Digite aqui o conteudo", 20, 46);

		this.panel.add(this.titleJ);
		this.panel.add(this.dateJ);
		this.panel.add(this.contentJ);

		return this.panel;
	}

	public void actionPerformed(ActionEvent e){
		Post post = new Post();
		post.setTitle(titleJ.getText());
		post.setDate(dateJ.getText());
		post.setContent(contentJ.getText());

		Blog blog = new Blog();
		blog.save(post, 1);
	}

}