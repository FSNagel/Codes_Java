import javax.swing.*;
import java.awt.event.*; 

class News extends Post implements ActionListener{
	private JPanel panel;
	private JTextField sourceJ;
	private JButton botaoSalvar;

	private String source;

	public String getSource(){
		return this.source;
	}

	public void setSource(String value){
		this.source = value;
	}

	public void show(){
		System.out.println("Post de News");
	}

	public JPanel getPanel(){
		this.panel = new JPanel();
		this.panel = super.getPanel();

		this.sourceJ = new JTextField("Informe a fonte:", 46);

		this.panel.add(this.sourceJ);
		
		return this.panel;
	}

	public void actionPerformed(ActionEvent e){
		News news = new News();
		news.setTitle(titleJ.getText());
		news.setDate(dateJ.getText());
		news.setContent(contentJ.getText());
		news.setSource(sourceJ.getText());

		Blog blog = new Blog();
		blog.save(news, 2);
	}

}